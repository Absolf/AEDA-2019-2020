#include "jogo.h"
#include <sstream>


//a alterar
ostream &operator << (ostream &os, Circulo &c1)
{
	return os;
}


//a alterar
Jogo::Jogo(int niv, vector<int> &pontos, vector<bool> &estados)
{
}

//a alterar
string Jogo::escreveJogo()
{
	return "";
}

//a alterar
int Jogo::jogada()
{
	return 0;
}


//a alterar
int Jogo::maisVisitado()
{
	return 0;
}

