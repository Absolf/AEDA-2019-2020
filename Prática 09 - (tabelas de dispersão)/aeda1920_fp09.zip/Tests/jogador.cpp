#include "jogador.h"

//a alterar
void Jogador::adicionaAposta(const Aposta & ap)
{

}

//a alterar
unsigned Jogador::apostasNoNumero(unsigned num) const
{
	return 0;
}

//a alterar
tabHAposta Jogador::apostasPremiadas(const tabHInt & sorteio) const
{
	tabHAposta money;
	return money;
}
