#include "gtest/gtest.h"
#include "gmock/gmock.h"


int main(int argc, char* argv[]) {
    testing::InitGoogleTest(&argc, argv);
    std::cout << "AEDA 2019/2020 - Aula Pratica 2" << std::endl;
    return RUN_ALL_TESTS();;
}