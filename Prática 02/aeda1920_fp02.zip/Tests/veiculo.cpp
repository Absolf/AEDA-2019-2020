#include "veiculo.h"
#include <iostream>

using namespace std;

